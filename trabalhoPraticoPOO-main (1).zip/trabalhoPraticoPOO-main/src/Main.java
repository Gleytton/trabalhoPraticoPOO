import java.util.List;

public class Main {

    public static void main(String[] args) {
        Arquivos arquivos = new Arquivos();
        arquivos.lerAlunos();
        //arquivos.lerPerguntas();
//        Aluno novoAluno = new Aluno("lucass", "loga", "123", 1, 0, 0);
//        Aluno novoAluno1 = new Aluno("lucas", "loga", "123", 1, 0, 0);
//        Aluno novoAluno2 = new Aluno("lucasss", "loga", "123", 1, 0, 0);
//        Aluno novoAluno3 = new Aluno("lucassss", "loga", "123", 1, 0, 0);
//        Aluno novoAluno4 = new Aluno("lucasssss", "loga", "123", 1, 0, 0);
//        arquivos.salvarAluno(novoAluno);
//        arquivos.salvarAluno(novoAluno1);
//        arquivos.salvarAluno(novoAluno2);
//        arquivos.salvarAluno(novoAluno3);
//        arquivos.salvarAluno(novoAluno4);
    }
}